@extends('layouts.site')

@section('title', 'Support & care plans — Astra Lab')
@section('description', 'Installation help, product uploads, SEO, Facebook Pixel and advertising support for your Astra Lab store. Monthly, 6-month and yearly care plans.')

@section('content')
<main>

  <section class="wrap page-head">
    <p class="eyebrow">Support &amp; services</p>
    <h1 style="margin-top:12px">You run the shop. We keep it running.</h1>
    <p class="lede" style="margin:18px auto 0">
      The software is yours and it works on its own. These are for when you would rather not do
      the technical parts yourself — setting it up, loading products, getting found on Google, or
      running ads that actually sell.
    </p>
  </section>

  <!-- ---------- one-off add-ons ---------- -->
  <section class="section">
    <div class="wrap">
      <div class="center stack" style="margin-bottom:32px">
        <p class="eyebrow">One-off help</p>
        <h2>Pay once, we do it for you</h2>
      </div>

      <div class="grid grid--2">
        <div class="card addon addon--featured">
          <div class="addon-head">
            <h3>Installation &amp; setup</h3>
            <div class="addon-price">
              <span class="addon-amount">৳500</span>
              <span class="addon-bundle">৳200 with the CMS</span>
            </div>
          </div>
          <p>We install it on your hosting, connect your database and domain, set up SSL, and hand
            you a working shop with your admin login. You send hosting details, we do the rest.</p>
          <p class="addon-note">Cheapest at checkout — add it to your order and it is ৳200 instead of ৳500.</p>
        </div>

        <div class="card addon">
          <div class="addon-head">
            <h3>Facebook Pixel &amp; tracking</h3>
            <div class="addon-price"><span class="addon-amount">৳800</span></div>
          </div>
          <p>Pixel and Conversions API installed and tested, plus standard events — view content,
            add to cart, purchase — so your ad reporting is accurate instead of guesswork.</p>
          <p class="addon-note">Includes Google Analytics 4 if you want it.</p>
        </div>

        <div class="card addon">
          <div class="addon-head">
            <h3>Product upload</h3>
            <div class="addon-price">
              <span class="addon-amount">৳1,500</span>
              <span class="addon-bundle">per 100 products</span>
            </div>
          </div>
          <p>Send us a spreadsheet or your existing Facebook page catalogue. We load products with
            names, prices, stock, categories and images, ready to sell.</p>
          <p class="addon-note">Photo editing and background removal quoted separately.</p>
        </div>

        <div class="card addon">
          <div class="addon-head">
            <h3>SEO starter setup</h3>
            <div class="addon-price"><span class="addon-amount">৳2,500</span></div>
          </div>
          <p>Titles and descriptions across your pages, sitemap, Google Search Console and Business
            Profile connected, plus a written list of what to fix next.</p>
          <p class="addon-note">A one-time setup, not ongoing work — see the care plans below.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- ---------- recurring care plans ---------- -->
  <section class="section section--tint">
    <div class="wrap">
      <div class="center stack" style="margin-bottom:26px">
        <p class="eyebrow">Care plans</p>
        <h2>Ongoing support, billed how you like</h2>
        <p class="lede">Pay for six months or a year up front and it costs less. Cancel a monthly
          plan whenever you want — your shop keeps working either way, because you own it.</p>
      </div>

      <div class="billing" role="group" aria-label="Billing period">
        <button class="billing-opt is-active" data-period="monthly" aria-pressed="true">Monthly</button>
        <button class="billing-opt" data-period="six" aria-pressed="false">6 months <span class="save">−10%</span></button>
        <button class="billing-opt" data-period="year" aria-pressed="false">Yearly <span class="save">−20%</span></button>
      </div>

      <div class="grid grid--3" style="margin-top:30px;align-items:stretch">

        <article class="card plan" data-monthly="800" data-six="4300" data-year="7700">
          <h3>Basic care</h3>
          <p class="plan-for">For a shop that is running fine and should stay that way.</p>
          <p class="plan-price"><span class="plan-amount">৳800</span><span class="plan-period">/month</span></p>
          <p class="plan-equiv"></p>
          <ul class="tick-list">
            <li><span class="tick" aria-hidden="true">✓</span> Updates checked and applied for you</li>
            <li><span class="tick" aria-hidden="true">✓</span> Weekly offsite backup</li>
            <li><span class="tick" aria-hidden="true">✓</span> Uptime monitoring, we notice before you do</li>
            <li><span class="tick" aria-hidden="true">✓</span> Email support, replies within 2 working days</li>
          </ul>
          <a class="btn btn--ghost" href="{{ route('shop') }}" style="margin-top:22px">Choose Basic</a>
        </article>

        <article class="card plan plan--popular" data-monthly="2500" data-six="13500" data-year="24000">
          <span class="plan-tag">Most chosen</span>
          <h3>Growth</h3>
          <p class="plan-for">For a shop actively adding products and chasing traffic.</p>
          <p class="plan-price"><span class="plan-amount">৳2,500</span><span class="plan-period">/month</span></p>
          <p class="plan-equiv"></p>
          <ul class="tick-list">
            <li><span class="tick" aria-hidden="true">✓</span> Everything in Basic</li>
            <li><span class="tick" aria-hidden="true">✓</span> Up to 50 product uploads a month</li>
            <li><span class="tick" aria-hidden="true">✓</span> Ongoing on-page SEO and keyword work</li>
            <li><span class="tick" aria-hidden="true">✓</span> Pixel and analytics kept working</li>
            <li><span class="tick" aria-hidden="true">✓</span> Monthly report in plain language</li>
            <li><span class="tick" aria-hidden="true">✓</span> WhatsApp support, same working day</li>
          </ul>
          <a class="btn btn--primary" href="{{ route('shop') }}" style="margin-top:22px">Choose Growth</a>
        </article>

        <article class="card plan" data-monthly="5000" data-six="27000" data-year="48000">
          <h3>Full service</h3>
          <p class="plan-for">For when you would rather sell than manage any of this.</p>
          <p class="plan-price"><span class="plan-amount">৳5,000</span><span class="plan-period">/month</span></p>
          <p class="plan-equiv"></p>
          <ul class="tick-list">
            <li><span class="tick" aria-hidden="true">✓</span> Everything in Growth</li>
            <li><span class="tick" aria-hidden="true">✓</span> Facebook and Google ads managed for you</li>
            <li><span class="tick" aria-hidden="true">✓</span> Creatives and ad copy written</li>
            <li><span class="tick" aria-hidden="true">✓</span> Unlimited product uploads</li>
            <li><span class="tick" aria-hidden="true">✓</span> Monthly strategy call</li>
            <li><span class="tick" aria-hidden="true">✓</span> Priority support, replies within hours</li>
          </ul>
          <a class="btn btn--ghost" href="{{ route('shop') }}" style="margin-top:22px">Choose Full service</a>
        </article>

      </div>

      <div class="card" style="margin-top:22px;border-left:3px solid var(--brand)">
        <h3>What advertising cost actually means</h3>
        <p style="margin-top:6px">Full service covers <em>managing</em> your ads. The money Facebook
          and Google charge to show them is separate and paid by you directly to them — we never
          add a margin to your ad spend, and you keep control of the account. Most shops start
          somewhere around ৳5,000–15,000 a month in spend, but that is entirely your call.</p>
      </div>
    </div>
  </section>

  <!-- ---------- comparison ---------- -->
  <section class="section">
    <div class="wrap" style="max-width:900px">
      <div class="center stack" style="margin-bottom:26px">
        <h2>Which plan fits</h2>
      </div>
      <!-- Every cell carries data-label so the narrow layout can name the plan
           it belongs to. Below 760px the table stops being a table and each
           feature becomes its own block — three columns cannot be read at
           375px, and sideways scrolling hides the two plans a visitor is
           trying to compare against. -->
      <table class="compare">
        <thead>
          <tr><th>What you get</th><th>Basic</th><th>Growth</th><th>Full service</th></tr>
        </thead>
        <tbody>
          <tr>
            <td>Updates and backups</td>
            <td data-label="Basic">✓</td><td data-label="Growth">✓</td><td data-label="Full service">✓</td>
          </tr>
          <tr>
            <td>Uptime monitoring</td>
            <td data-label="Basic">✓</td><td data-label="Growth">✓</td><td data-label="Full service">✓</td>
          </tr>
          <tr>
            <td>Product uploads</td>
            <td data-label="Basic">—</td><td data-label="Growth">50 / month</td><td data-label="Full service">Unlimited</td>
          </tr>
          <tr>
            <td>Ongoing SEO</td>
            <td data-label="Basic">—</td><td data-label="Growth">✓</td><td data-label="Full service">✓</td>
          </tr>
          <tr>
            <td>Pixel &amp; analytics upkeep</td>
            <td data-label="Basic">—</td><td data-label="Growth">✓</td><td data-label="Full service">✓</td>
          </tr>
          <tr>
            <td>Ads managed</td>
            <td data-label="Basic">—</td><td data-label="Growth">—</td><td data-label="Full service">✓</td>
          </tr>
          <tr>
            <td>Support speed</td>
            <td data-label="Basic">2 working days</td><td data-label="Growth">Same working day</td><td data-label="Full service">Within hours</td>
          </tr>
        </tbody>
      </table>
    </div>
  </section>

  <section class="section section--tint" id="faq">
    <div class="wrap" style="max-width:820px">
      <div class="center stack" style="margin-bottom:26px">
        <p class="eyebrow">FAQ</p>
        <h2>Before you sign up</h2>
      </div>
      <div class="faq">
        <details>
          <summary>Do I need a care plan at all?</summary>
          <p>No. The CMS is yours and runs without us — updates arrive in your admin panel and you
            can apply them yourself in a couple of clicks. These plans are for people who would
            rather not.</p>
        </details>
        <details>
          <summary>What happens if I cancel?</summary>
          <p>Your shop carries on exactly as before. You stop getting the service, not the
            software. Nothing is locked and nothing is taken away.</p>
        </details>
        <details>
          <summary>Is the ৳200 installation available later?</summary>
          <p>The ৳200 price is for adding installation to your order at checkout, because we set it
            up while your details are already in front of us. Booking it separately afterwards is
            ৳500.</p>
        </details>
        <details>
          <summary>Do unused product uploads roll over?</summary>
          <p>No. The Growth allowance is 50 in a month and resets each month. If you have a large
            one-off catalogue, the ৳1,500 per 100 products add-on is usually cheaper.</p>
        </details>
        <details>
          <summary>Can I change plan later?</summary>
          <p>Yes, at any time. Moving up takes effect immediately and we adjust the difference;
            moving down applies at your next billing date.</p>
        </details>
      </div>
    </div>
  </section>

  <section class="section">
    <div class="wrap">
      <div class="cta">
        <h2>Not sure which one?</h2>
        <p class="lede" style="margin:12px auto 0;color:rgba(255,255,255,.9)">
          Tell us what you sell and how many products you have. We will say plainly which plan
          fits — including if that is none of them.
        </p>
        <div class="hero-actions" style="justify-content:center">
          <a class="btn btn--lg" href="{{ route('contact') }}" style="background:#fff;color:var(--brand-dark)">Ask us</a>
        </div>
      </div>
    </div>
  </section>

</main>
@endsection
