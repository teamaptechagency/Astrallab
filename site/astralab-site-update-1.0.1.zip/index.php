<?php

/*
 * Where the application lives, relative to this file.
 *
 * Three places, furthest from the web root first. astralab-app/ holds
 * .env; inside the web root those files have URLs, and the only thing
 * in front of them is an .htaccess that denies everything — which
 * works until a server stops honouring .htaccess, and then stops
 * silently. Two levels up is outside every document root on the
 * account: protection by the filesystem rather than by a rule.
 */
$candidates = [
    __DIR__.'/../../astralab-app',
    __DIR__.'/../astralab-app',
    __DIR__.'/astralab-app',
];

$astralab = null;

foreach ($candidates as $candidate) {
    if (is_file($candidate.'/vendor/autoload.php')) {
        $astralab = $candidate;
        break;
    }
}

if ($astralab === null) {
    http_response_code(500);
    exit('The application folder was not found. astralab-app/ should be beside '
        .'public_html, beside this index.php, or two levels above it.');
}

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

// Determine if the application is in maintenance mode...
if (file_exists($maintenance = $astralab.'/storage/framework/maintenance.php')) {
    require $maintenance;
}

// Register the Composer autoloader...
require $astralab.'/vendor/autoload.php';

// Bootstrap Laravel and handle the request...
/** @var Application $app */
$app = require_once $astralab.'/bootstrap/app.php';

$app->handleRequest(Request::capture());
