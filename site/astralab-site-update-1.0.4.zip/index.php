<?php

/*
 * Where the application lives, relative to this file.
 *
 * Three places, furthest from the web root first. astralab-app/ holds
 * .env; inside the web root those files have URLs, and the only thing
 * in front of them is an .htaccess that denies everything — which
 * works until a server stops honouring .htaccess, and then stops
 * silently. Two levels up is outside every document root on the
 * account: protection by the filesystem rather than by a rule.
 */
$candidates = [
    __DIR__.'/../../astralab-app',
    __DIR__.'/../astralab-app',
    __DIR__.'/astralab-app',
];

$astralab = null;

foreach ($candidates as $candidate) {
    if (is_file($candidate.'/vendor/autoload.php')) {
        $astralab = $candidate;
        break;
    }
}

if ($astralab === null) {
    http_response_code(500);
    exit('The application folder was not found. astralab-app/ should be beside '
        .'public_html, beside this index.php, or two levels above it.');
}

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

// Determine if the application is in maintenance mode...
//
// Two files, and only one of them decides. `down` is the flag the
// framework reads; maintenance.php is the pre-rendered page this file
// serves when it is there. Clearing one and not the other leaves the
// site shut with a nice page, or open with none — so both are cleared
// together, or neither is.
$astralabDown = [
    $astralab.'/storage/framework/down',
    $astralab.'/storage/framework/maintenance.php',
];

$astralabClosedAt = 0;

foreach ($astralabDown as $astralabFile) {
    if (file_exists($astralabFile)) {
        $astralabClosedAt = max($astralabClosedAt, (int) filemtime($astralabFile));
    }
}

if ($astralabClosedAt > 0 && $astralabClosedAt < time() - 900) {
    // A swap that died mid-flight. Fifteen minutes is far longer than
    // any of them takes and far shorter than a working day.
    foreach ($astralabDown as $astralabFile) {
        @unlink($astralabFile);
    }
} elseif (file_exists($maintenance = $astralab.'/storage/framework/maintenance.php')) {
    require $maintenance;
}

// Register the Composer autoloader...
require $astralab.'/vendor/autoload.php';

// Bootstrap Laravel and handle the request...
/** @var Application $app */
$app = require_once $astralab.'/bootstrap/app.php';

$app->handleRequest(Request::capture());
